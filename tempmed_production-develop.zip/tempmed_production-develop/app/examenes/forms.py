from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateTimeField, TextAreaField, SelectField
from wtforms.validators import DataRequired,InputRequired

class RegisterExamenes(FlaskForm):
    examen_id = IntegerField('ID del Examen', validators=[InputRequired()])
    medico_id = IntegerField('ID del Médico', validators=[InputRequired()])
    paciente_id = IntegerField('ID del Paciente', validators=[InputRequired()])
    empresa_id = IntegerField('ID de la Empresa', validators=[InputRequired()])
    sucursal_id = IntegerField('ID de la Sucursal')
    tipo_de_examen = StringField('Tipo de Examen', validators=[InputRequired()])
    resultados = TextAreaField('Resultados')
    estado = SelectField('Estado', choices=[('Pendiente', 'Pendiente'), ('Completado', 'Completado'), ('Rechazado', 'Rechazado')],
                         validators=[DataRequired()])
    # Agrega más campos aquí según tus necesidades

