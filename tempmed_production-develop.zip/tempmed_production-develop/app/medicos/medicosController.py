from flask import Blueprint, render_template, flash, redirect, jsonify, request, url_for
from app.db import db
from app.medicos.models import Medicos
from app.medicos.forms import RegisterMedico
from flask_login import current_user
from app.pacientes.pacienteController import validaRut
medicoBP = Blueprint('medico', __name__)

@medicoBP.route('/registrar_medico', methods=('GET', 'POST'))
def registrar_medico():
    form = RegisterMedico()
    if form.validate_on_submit():
        
        
        if not validaRut(form.rut.data):
            print(form.rut.data)
        
            flash("El Rut ingresado no tiene un formato valido.", "error")
            return redirect('/registrar_medico')
        if Medicos.query.filter_by(correo_electronico=form.correo_electronico.data).first():
            flash("El medico ingresado, ya se encuentra registrado en el sistema", "error")
            return redirect('/registrar_medico')
        else:
            medico = Medicos(
                pnombre=form.pnombre.data,
                snombre=form.snombre.data,
                papellido=form.papellido.data,
                sapellido=form.sapellido.data,
                rut=form.rut.data,
                especialidad=form.especialidad.data,
                subespecialidad=form.subespecialidad.data,
                fecha_nacimiento=form.fecha_nacimiento.data,
                genero=form.genero.data,
                direccion=form.direccion.data,
                correo_electronico=form.correo_electronico.data,
                estado_licencia=form.estado_licencia.data,
                telefono=form.telefono.data,
                fecha_ingreso=form.fecha_ingreso.data,
                foto=form.foto.data,
                educacion=form.educacion.data,
                horario_atencion=form.horario_atencion.data,
                id_centro_clinico=current_user.centro_actual
            )
            db.session.add(medico)
            db.session.commit()
            flash("Médico registrado correctamente")
            return redirect('/registrar_medico')
    return render_template('medicos/registrar_medico.html', form=form)

@medicoBP.route('/medicos/lista_medicos', methods=('GET', 'POST'))
def listar_medicos():
    return render_template('medicos/listar_medicos.html')

@medicoBP.route('/medicos_listar_api', methods=['GET'])
def listar_medicos_api():
    medicos = Medicos.query.filter_by(id_centro_clinico=current_user.centro_actual)
    
    medicos_serializable = []
    for medico in medicos:
        medico_dict = {
            'id_medico': medico.id_medico,
            'pnombre': medico.pnombre,
            'papellido': medico.papellido,
            'sapellido': medico.sapellido,
            'rut': medico.rut,
            'especialidad': medico.especialidad,
            'direccion': medico.direccion,
            'correo_electronico': medico.correo_electronico,
            'telefono': medico.telefono,
            'fecha_ingreso': medico.fecha_ingreso.isoformat() if medico.fecha_ingreso else None,
            'horario_atencion': medico.horario_atencion
        }
        medicos_serializable.append(medico_dict)
    return jsonify({'medicos': medicos_serializable})


@medicoBP.route('/medicos/editar_medico/<medico_id>', methods=['GET', 'POST'])
def editar_medico(medico_id):
    form = RegisterMedico()
    medico = Medicos.query.filter_by(id_medico=medico_id).first()
    if medico:
        if request.method == 'POST':
            if form.validate_on_submit():
                medico.pnombre = form.pnombre.data
                medico.snombre = form.snombre.data
                medico.papellido = form.papellido.data
                medico.sapellido = form.sapellido.data
                medico.rut = form.rut.data
                medico.especialidad = form.especialidad.data
                medico.subespecialidad = form.subespecialidad.data
                medico.fecha_nacimiento = form.fecha_nacimiento.data
                medico.genero = form.genero.data
                medico.direccion = form.direccion.data
                medico.correo_electronico = form.correo_electronico.data
                medico.estado_licencia = form.estado_licencia.data
                medico.telefono = form.telefono.data
                medico.fecha_ingreso = form.fecha_ingreso.data
                medico.foto = form.foto.data
                medico.educacion = form.educacion.data
                medico.horario_atencion = form.horario_atencion.data
                db.session.commit()
                flash("Médico editado correctamente.", "success")
                return redirect(url_for('medico.listar_medicos'))
            else:
                flash("Error al actualizar los datos.", "error")
        else:
            form.pnombre.data = medico.pnombre
            form.snombre.data = medico.snombre
            form.papellido.data = medico.papellido
            form.sapellido.data = medico.sapellido
            form.rut.data = medico.rut
            form.especialidad.data = medico.especialidad
            form.subespecialidad.data = medico.subespecialidad
            form.fecha_nacimiento.data = medico.fecha_nacimiento
            form.genero.data = medico.genero
            form.direccion.data = medico.direccion
            form.correo_electronico.data = medico.correo_electronico
            form.estado_licencia.data = medico.estado_licencia
            form.telefono.data = medico.telefono
            form.fecha_ingreso.data = medico.fecha_ingreso
            form.foto.data = medico.foto
            form.educacion.data = medico.educacion
            form.horario_atencion.data = medico.horario_atencion
        return render_template('medicos/editar_medico.html', form=form, medico_id=medico_id)
    else:
        flash("Médico no encontrado.", "error")
        return redirect(url_for('medico.listar_medicos'))

    
    
@medicoBP.route('/medicos/eliminar_medico', methods=['POST'])
def eliminar_medico_api():
    medico_id = request.form.get('medico_id')
    medico = Medicos.query.filter_by(id_medico=medico_id).first()
    if medico:
        db.session.delete(medico)
        db.session.commit()
        return jsonify({"message": "Médico eliminado correctamente"})
    else:
        return jsonify({"message": "Médico no encontrado"})
    
