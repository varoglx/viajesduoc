from app.db import db
from sqlalchemy import create_engine, Column
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
from app.asociaciones.models import asociacion_usuario_sucursal
class Sucursales(db.Model):
    # Tabla para representar las sucursales de un centro médico

    # Identificador único para cada sucursal.
    id = db.Column(db.Integer, primary_key=True)
    
    # Nombre de la sucursal.
    nombre = db.Column(db.String(50), nullable=False)
    
    # Dirección de la sucursal.
    direccion = db.Column(db.String(50), nullable=False)
    
    # Comuna en la que se encuentra la sucursal.
    comuna = db.Column(db.String(50), nullable=False)
    
    # Región en la que se encuentra la sucursal.
    region = db.Column(db.String(50), nullable=False)
    
    # Número telefónico de contacto de la sucursal.
    telefono = db.Column(db.String(50))
    
    # Dirección de correo electrónico de la sucursal.
    correo_electronico = db.Column(db.String(50))
    
    # Fecha en que la sucursal fue inaugurada o abierta.
    fecha_creacion = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Indica si la sucursal está activa o no.
    activa = db.Column(db.Boolean, default=True)
    
    # Clave foránea que relaciona la sucursal con su centro clinico.
    id_centro_clinico = db.Column(db.Integer, db.ForeignKey('centros_clinicos.id'), nullable=False)
    
    # Relación para conectar la sucursal con su empresa correspondiente.
    centro_clinico = relationship('CentrosClinicos', back_populates='sucursales')
    usuarios = relationship('Usuarios', secondary=asociacion_usuario_sucursal, back_populates='sucursales')

