from flask import Blueprint,render_template,flash,redirect,jsonify,request,url_for
from app.db import db
from flask_login import current_user
from app.pacientes.models import Pacientes
from app.pacientes.forms import RegisterPaciente



pacienteBP = Blueprint('paciente',__name__)




@pacienteBP.route('/registrar_paciente', methods=('GET', 'POST'))
def registrar_paciente():
    form = RegisterPaciente()
        
    if form.validate_on_submit():
        print(form.rut.data)
        if not validaRut(form.rut.data):
            flash("El Rut ingresado no tiene un formato valido.", "error")
            return redirect('/registrar_paciente')

        if Pacientes.query.filter_by(rut=form.rut.data, id_centro_clinico = current_user.centro_actual).first():
            flash("El paciente ingresado, ya se encuentra registrado en el sistema", "error")
            return redirect('/registrar_paciente')
        else:
            paciente = Pacientes()
            paciente.rut = form.rut.data
            paciente.nombre = form.nombre.data
            paciente.prevision = form.prevision.data
            #paciente.edad = form.edad.data
            paciente.apellidos = form.apellidos.data
            paciente.fecha_nacimiento = form.fecha_nacimiento.data
            paciente.genero = form.genero.data
            paciente.direccion = form.direccion.data
            paciente.ciudad = form.ciudad.data
            paciente.telefono = form.telefono.data
            paciente.email = form.email.data
            paciente.seguro_medico = form.seguro_medico.data
            paciente.id_centro_clinico = current_user.centro_actual 

            db.session.add(paciente)
            db.session.commit()
            flash("Paciente registrado correctamente")
            return redirect('/registrar_paciente')
    else:
        if form.errors:
            print(form.errors)
    return render_template('paciente/registrar_paciente.html',form=form)



@pacienteBP.route('/pacientes/lista_pacientes', methods=('GET', 'POST'))
def listar_pacientes_view():
        return render_template('paciente/listar_pacientes.html')

@pacienteBP.route('/pacientes_listar_api', methods=['GET'])
def listar_pacientes_api():
    pacientes = Pacientes.query.filter_by(id_centro_clinico = current_user.centro_actual)#fitlrar por el id_clinica que tenga el usuario que esta solicitando el listado
    pacientes_serializable = []
    for paciente in pacientes:
        paciente_dict = {
            'id': paciente.id,
            'rut': paciente.rut,
            'nombre': paciente.nombre,
            'apellidos': paciente.apellidos,
            'prevision': paciente.prevision,
            #'edad': paciente.apellidos,
            'fecha_nacimiento': paciente.fecha_nacimiento.isoformat() if paciente.fecha_nacimiento else None,
            'direccion': paciente.direccion,
            'ciudad': paciente.ciudad,
            'telefono': paciente.telefono,
            'email': paciente.email,
            'seguro_medico': paciente.seguro_medico,
            'ultima_visita': paciente.ultima_visita.isoformat() if paciente.ultima_visita else None,
        }
        pacientes_serializable.append(paciente_dict)
    
    return jsonify({'pacientes': pacientes_serializable})

@pacienteBP.route('/pacientes/editar_paciente/<paciente_id>', methods=['GET','POST'])
def editar_paciente(paciente_id):
        form = RegisterPaciente()
        paciente = Pacientes.query.filter_by(id=paciente_id).first()
        if paciente:
             if request.method == 'POST':
                   if not validaRut(request.form.get('rut')):
                    flash("El Rut ingresado no tiene un formato valido.", "error")
                    redirect(url_for('paciente.editar_paciente', paciente_id=paciente_id))
                   else:
                    paciente.rut = request.form.get('rut')
                    paciente.nombre = request.form.get('nombre')  
                    paciente.apellidos = request.form.get('apellidos')  
                    paciente.prevision = request.form.get('prevision')  
                    paciente.fecha_nacimiento = request.form.get('fecha_nacimiento')  
                    #paciente.edad = request.form.get('edad')  
                    paciente.genero = request.form.get('genero')  
                    paciente.direccion = request.form.get('direccion')  
                    paciente.ciudad = request.form.get('ciudad')  
                    paciente.telefono = request.form.get('telefono')  
                    paciente.email = request.form.get('email')  
                    paciente.seguro_medico = request.form.get('seguro_medico')  
                    #paciente.medico_asignado = request.form.get('medico_asignado')  
                    #paciente.ultima_visita = request.form.get('ultima_visita')  
                    paciente.notas = request.form.get('notas')  
                    paciente.id_centro_clinco = request.form.get('id_centro_clinco')  

                    db.session.commit()
                    flash("Paciente editado correctamente.", "succes")

        return render_template('paciente/editar_paciente.html', pacientes=paciente,form=form)

@pacienteBP.route('/pacientes/eliminar_paciente', methods=['GET','POST'])
def eliminar_paciente_api():
    paciente_id = request.form.get('id_paciente') 
    paciente = Pacientes.query.filter_by(id=paciente_id).first()
    if paciente:
        db.session.delete(paciente)
        db.session.commit()
        return jsonify({"message": "Paciente eliminado correctamente"})
    else:
        return jsonify({"message": "Paciente no encontrado"})

#esta funcion se puede reutilizar y por orden siempre dejarla al final del codigo.
def validaRut(r):
    sub_rut, sub_dv = r.split('-')
    sub_dv = sub_dv.upper()
    x = 2
    s = 0
    for i in range(len(sub_rut) - 1, -1, -1):
        if x > 7:
            x = 2
        s += int(sub_rut[i]) * x
        x += 1

    dv = 11 - (s % 11)

    if dv == 10:
        dv = 'K'
    elif dv == 11:
        dv = '0'
    else:
        dv = str(dv)

    return dv == sub_dv

# Probar la función con el RUT 19095970-8
print(validaRut("19095970-8")) 

# Ejemplo de uso
  # Debería devolver True o False dependiendo de si el RUT es válido o no
