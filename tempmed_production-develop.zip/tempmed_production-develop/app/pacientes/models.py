from app.db import db
from sqlalchemy import Column, Date

class Pacientes(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rut = db.Column(db.String(100))
    nombre = db.Column(db.String(100))
    apellidos = db.Column(db.String(100))
    prevision = db.Column(db.String(100))
    fecha_nacimiento = db.Column(Date)
    #edad = db.Column(db.Integer)
    genero = db.Column(db.String(100))
    direccion = db.Column(db.String(100))
    ciudad = db.Column(db.String(150))
    telefono = db.Column(db.String(150))
    email = db.Column(db.String(150))
    seguro_medico = db.Column(db.String(150)) #este puede ser un id 
    fecha_registro = db.Column(Date) #esto tiene que ser un timestamp
    medico_asignado = db.Column(db.String(150)) #esto puede ser por si lo solictan por lo general tienen mas de un medico en los centros medicos 
    ultima_visita = db.Column(Date)
    notas = db.Column(db.String(150))
    id_centro_clinico = db.Column(db.Integer, db.ForeignKey('centros_clinicos.id'), nullable=False)

    #guardar usuario que registra
    #crear una tabla con ficha, clinica
    #historial medico
    #recetas
    #visitas
    #atenciones
   
  