from flask import Blueprint,render_template,url_for,redirect,flash,jsonify,request
from werkzeug.security import generate_password_hash,check_password_hash
from app.user.models import Usuarios,UsuariosCentro
from app.user.forms import RegisterForm,LoginForm
from app.centros_clinicos.models import CentrosClinicos
from app.db import db
from app import login_manager   
from flask_login import login_user,current_user,login_required,logout_user
from flask import session
from app.asociaciones.models import asociacion_usuario_centro_clinico
from app import app

@login_manager.user_loader
def load_user(user_id):
    
    return Usuarios.query.get(user_id)

usuarioBP = Blueprint('user',__name__)


@usuarioBP.route('/registrar_usuario', methods=('GET', 'POST'))
def register():
    
    form = RegisterForm(meta={ 'csrf':False})

    if form.validate_on_submit():
        centro_clinico_id = request.form.get('id_centro_clinico')

        if Usuarios.query.filter_by(username=form.username.data).first():#replicar para email
            flash("Usuario duplicado", "error")
            return redirect(url_for('user.register'))

        else:
            user = Usuarios()
            user.username = form.username.data
            user.password = generate_password_hash(form.password.data)
            user.nombre = form.nombre.data
            user.apellido = form.apellido.data    
            user.email = form.email.data
            user.centro_actual = centro_clinico_id

            db.session.add(user)
            db.session.commit()

            user_centro = UsuariosCentro()  # Crear una instancia de UsuariosCentro
            user_centro.id_usuario = user.id  # Asignar el ID del usuario
            user_centro.es_admin = 1
            user_centro.id_centro = centro_clinico_id
            db.session.add(user_centro)
            db.session.commit()

            login_user(user,remember=True)
            flash("Usuario registrado con exito!!!", "succes")
            return redirect(url_for('user.register'))

    if form.errors:
        print(form.errors)
    return render_template('user/register_user.html',form=form)

@usuarioBP.route('/', methods=['GET', 'POST'])
def login():
    


    form = LoginForm()
    if form.validate_on_submit():#valida el formulario 
        user = Usuarios.query.filter_by(username=form.username.data).first()#consulta si esta el usuario
        
        if user:
            if check_password_hash(user.password, form.password.data):
                login_user(user)
                return redirect(url_for('index'))
            else:
                flash('Usuario o contraseña incorrectos.', 'error')
                return redirect(url_for('user.login'))
                
        else:
            flash('Usuario o contraseña incorrectos.', 'error')
            return redirect(url_for('user.login'))  



    return render_template('user/login.html', form=form)

@usuarioBP.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('user.login'))


@usuarioBP.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    return render_template('user/dashboard.html')


@usuarioBP.route('/perfil')
def perfil():
    return render_template('user/dashboard.html')

@usuarioBP.route('/obtener_centros_clinicos_api',methods=['GET', 'POST'])
def obtener_centros_clinicos_api():
    centros = CentrosClinicos.query.all()
    centros_clinicos_serializable = []
    for c in centros:

       centros_dict = {
            'id': c.id,
            'rut': c.rut
        }
       centros_clinicos_serializable.append(centros_dict)
 
    return jsonify({'centros': centros_clinicos_serializable})




@app.route('/seleccionar_clinica', methods=['GET', 'POST'])
def seleccionar_clinica():
    if not current_user.is_authenticated:
        flash('Por favor inicia sesión para acceder a esta página.', 'error')
        return redirect(url_for('login'))
    
    clinicas_asociadas = current_user.centro_clinico
    
    if request.method == 'POST':
        centro_clinico_id = request.form.get('centro_clinico_id')
        if centro_clinico_id:
            session['centro_clinico_id'] = centro_clinico_id
            print('este es el id del centro medico ',session['centro_clinico_id'])
            return redirect(url_for('index'))

    return render_template('user/seleccionar_clinica.html', clinicas=clinicas_asociadas)
