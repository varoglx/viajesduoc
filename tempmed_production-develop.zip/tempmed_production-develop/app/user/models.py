from flask_login import UserMixin
from app.db import db
from werkzeug.security import check_password_hash
from app.centros_clinicos.models import CentrosClinicos
from sqlalchemy.orm import relationship
from app.asociaciones.models import asociacion_usuario_sucursal,asociacion_usuario_centro_clinico,asociacion_rol_sucursal,asociacion_rol_centro_clinico


class Usuarios(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100))
    username = db.Column(db.String(100))
    nombre = db.Column(db.String(100))
    apellido = db.Column(db.String(100))
    centro_actual = db.Column(db.Integer, db.ForeignKey('centros_clinicos.id'), nullable=False)
    password = db.Column(db.String(150))
    roles_por_sucursal = relationship('Roles', secondary=asociacion_rol_sucursal, back_populates='usuarios_por_sucursal')
    roles_por_centro_clinico = relationship('Roles', secondary=asociacion_rol_centro_clinico, back_populates='usuarios_por_centro_clinico')
    centro_clinico = relationship('CentrosClinicos', secondary=asociacion_usuario_centro_clinico, back_populates='usuarios')#columna obsoleta
    sucursales = relationship('Sucursales', secondary=asociacion_usuario_sucursal, back_populates='usuarios')
    def check_password(self,password):
     return check_password_hash(self.password,password)
    
class UsuariosCentro(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    es_admin = db.Column(db.Integer)
    id_centro = db.Column(db.Integer, db.ForeignKey('centros_clinicos.id'), nullable=False)
    id_usuario = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    
    