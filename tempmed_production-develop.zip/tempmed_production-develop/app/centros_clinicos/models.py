from app.db import db
from sqlalchemy import Column, Date
from sqlalchemy.orm import relationship

from app.asociaciones.models import asociacion_usuario_centro_clinico
class CentrosClinicos(db.Model):
    
    id = db.Column(db.Integer, primary_key=True)
    rut = db.Column(db.String(100))
    nombre = db.Column(db.String(100))
    ciudad = db.Column(db.String(100))
    comuna = db.Column(db.String(100))
    fono = db.Column(db.String(100))
    correo_electronico = db.Column(db.String(100))
    especialidad = db.Column(db.String(150))
    fecha_fundacion = db.Column(Date)
    descripcion = db.Column(db.String(150))
    
    # Relaciones
    sucursales = relationship('Sucursales', back_populates='centro_clinico')
    usuarios = relationship('Usuarios', secondary=asociacion_usuario_centro_clinico, back_populates='centro_clinico')

   #37 a 38 minuto criticasqls entre la hora 50 y 58