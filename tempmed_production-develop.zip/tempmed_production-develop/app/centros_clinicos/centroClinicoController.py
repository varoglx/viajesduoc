from app.db import db
from flask import Blueprint,render_template
from app.centros_clinicos.models import CentrosClinicos
from app.centros_clinicos.forms import RegisterCentoClinico, EditarCentroClinico

CentroClinicoBP = Blueprint('centro_clinico',__name__)


@CentroClinicoBP.route('/registrar_centro_medico', methods=('GET', 'POST'))
def registerCentroClinico():
    form = RegisterCentoClinico()
    if form.validate_on_submit():
        print('valido')
        if CentrosClinicos.query.filter_by(rut=form.rut.data).first():
            print("este centro medico ya existe")
        else:
            centroClinico = CentrosClinicos()
            centroClinico.rut = form.rut.data
            centroClinico.nombre = form.nombre.data
            centroClinico.ciudad = form.ciudad.data
            centroClinico.comuna = form.comuna.data
            centroClinico.fono = form.fono.data
            centroClinico.especialidad = form.especialidad.data
            centroClinico.fecha_fundacion = form.fecha_fundacion.data
            centroClinico.descripcion =  form.descripcion.data
            centroClinico.correo_electronico = form.correo_electronico.data
            db.session.add(centroClinico)
            db.session.commit()
            print('guardado')


        if form.errors:
            print(form.errors)
    else:
        print('cualquier wea ')
    return render_template('centros_clinicos/register_centros_clinicos.html',form=form)

#falta listar,editar y eliminar