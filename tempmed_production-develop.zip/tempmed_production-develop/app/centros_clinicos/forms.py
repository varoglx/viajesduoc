from wtforms.validators import InputRequired,EqualTo
from flask_wtf import FlaskForm
from wtforms import StringField,DateField

class RegisterCentoClinico(FlaskForm):
    rut = StringField('RUT',validators=[ InputRequired() ])
    nombre = StringField('Nombre Centro Clinico ',validators=[ InputRequired() ])
    ciudad = StringField('Ciudad',validators=[ InputRequired() ])
    comuna = StringField('Comuna',validators=[ InputRequired() ])
    fono = StringField('Telefono',validators=[ InputRequired()])
    especialidad = StringField('Especialidad',validators=[ InputRequired() ])
    fecha_fundacion = DateField('Fecha Fundacion',validators=[ InputRequired() ])
    descripcion = StringField('Descripción',validators=[ InputRequired() ])
    correo_electronico = StringField('Email',validators=[ InputRequired() ])

class EditarCentroClinico(FlaskForm):
    rut = StringField('RUT',validators=[ InputRequired() ])
    nombre = StringField('Nombre Centro Clinico ',validators=[ InputRequired() ])
    ciudad = StringField('Ciudad',validators=[ InputRequired() ])
    comuna = StringField('Comuna',validators=[ InputRequired() ])
    fono = StringField('Telefono',validators=[ InputRequired()])
    especialidad = StringField('Especialidad',validators=[ InputRequired() ])
    fecha_fundacion = DateField('Fecha Fundacion',validators=[ InputRequired() ])
    descripcion = StringField('Descripción',validators=[ InputRequired() ])
    correo_electronico = StringField('Email',validators=[ InputRequired() ])

