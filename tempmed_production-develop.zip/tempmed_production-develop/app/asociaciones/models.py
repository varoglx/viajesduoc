from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from app.db import db

# Relación muchos-a-muchos entre Usuario y Sucursal
asociacion_usuario_sucursal = db.Table('asociacion_usuario_sucursal', db.metadata,
   db.Column('usuario_id', db.Integer, db.ForeignKey('usuarios.id')),
   db.Column('sucursal_id', db.Integer, db.ForeignKey('sucursales.id'))
)

# Relación muchos-a-muchos entre Usuario y Empresa
asociacion_usuario_centro_clinico = db.Table('asociacion_usuario_centro_clinico', db.metadata,
    db.Column('usuario_id', db.Integer, db.ForeignKey('usuarios.id')),
    db.Column('centroclinico_id', db.Integer, db.ForeignKey('centros_clinicos.id'))
)

asociacion_rol_sucursal = db.Table('asociacion_rol_sucursal', db.metadata,
    db.Column('usuario_id', db.Integer, db.ForeignKey('usuarios.id')),
    db.Column('rol_id', db.Integer, db.ForeignKey('roles.id')),
    db.Column('sucursal_id', db.Integer, db.ForeignKey('sucursales.id'))
)

asociacion_rol_centro_clinico = db.Table('asociacion_rol_centro_clinico', db.metadata,
    db.Column('usuario_id', db.Integer, db.ForeignKey('usuarios.id')),
    db.Column('rol_id', db.Integer, db.ForeignKey('roles.id')),
    db.Column('centro_clinico_id', db.Integer, db.ForeignKey('centros_clinicos.id'))
)

