from flask import Flask
#from flask_socketio import socketIO
 
from app.db import db, configure_db  # Importa la instancia de SQLAlchemy y la función configure_db desde db.py
from sqlalchemy import text  # Importa la función text de SQLAlchemy
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager



# Importa tus modelos y controladores aquí dentro del contexto de la aplicación
from app.user.models import Usuarios
from app.centros_clinicos.models import CentrosClinicos
from app.pacientes.models import Pacientes

from app.examenes.models import Examenes
from app.sucursales.models import Sucursales
from app.medicos.models import Medicos
from app.asociaciones.models import asociacion_usuario_centro_clinico,asociacion_usuario_sucursal,\
    asociacion_rol_centro_clinico,asociacion_rol_sucursal
from app.roles.models import Roles




app = Flask(__name__)

app.config['SECRET_KEY'] = "secret"
app.debug = True  # Activar el modo de depuración

#socketio = SocketIO(app)
 
#configuraciones
db = configure_db(app)
login_manager = LoginManager(app)
login_manager.login_view = 'user.login' # es la ruta donde sera redirigido el usuario al entrar a una pantalla a la cual no tiene permisos.


#importacion de vistas
from app.controllers import general # import de Blueprint de controllers
from app.user.userController import usuarioBP
from app.centros_clinicos.centroClinicoController import CentroClinicoBP
from app.pacientes.pacienteController import pacienteBP
from app.examenes.examenesController import examenesBP
from app.medicos.medicosController import medicoBP






# Configura la base de datos usando la función configure_db importada
app.register_blueprint(general)
app.register_blueprint(usuarioBP)
app.register_blueprint(CentroClinicoBP)
app.register_blueprint(pacienteBP)
app.register_blueprint(examenesBP)
app.register_blueprint(medicoBP)

